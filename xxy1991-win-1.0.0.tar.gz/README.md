# Ansible Collection - xxy1991.win

Documentation for the collection.

Linting
-------------

```bash
set -e
yamllint .
ansible-lint
# flake8
```
